using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Varonis.Sentinel.Functions.LogAnalytics;
using Varonis.Sentinel.Functions.DatAlert;
using Varonis.Sentinel.Functions.Helpers;

namespace Varonis.Sentinel.Functions
{
    public class FetchDataFunction
    {
        [FunctionName("VaronisDSP")]
        public async Task Run([TimerTrigger("0 * * * * *")]TimerInfo timer, ILogger log)
        {
            try
            {
                var hostname = Environment.GetEnvironmentVariable("DatAlertHostName");
                var datalertApiKey = Environment.GetEnvironmentVariable("DatAlertApiKey");
                var logAnalyticsKey = Environment.GetEnvironmentVariable("LogAnalyticsKey");
                var logAnalyticsWorkspace = Environment.GetEnvironmentVariable("LogAnalyticsWorkspace");

                var firstFetchTimeStr = Environment.GetEnvironmentVariable("FirstFetchTime");
                var severities = Environment.GetEnvironmentVariable("Severities");
                var threatModelName = Environment.GetEnvironmentVariable("ThreatModelNameList");

                var baseUri = new Uri($"https://{hostname}");

                var client = new DatAlertClient(baseUri, datalertApiKey, log);
                var storage = new LogAnalyticsFake(log); //new LogAnalyticsCollector(logAnalyticsKey, logAnalyticsWorkspace, log);

                if (timer.IsPastDue)
                {
                    log.LogInformation("Timer is running late!");
                }

                var minDate = DateTime.MinValue.ToUniversalTime();

                var last = timer.ScheduleStatus.Last.ToUniversalTime();
                var lastUpdated = timer.ScheduleStatus.LastUpdated.ToUniversalTime();
                var next = timer.ScheduleStatus.Next.ToUniversalTime();

                log.LogInformation($"Schedule status: {last}, {lastUpdated}, {next}");

                if (last == minDate && !string.IsNullOrWhiteSpace(firstFetchTimeStr))
                {
                    lastUpdated = DateParser.Parse(firstFetchTimeStr);
                }

                log.LogInformation($"DatAlert host name: {hostname}; LogAnalytics Key: {logAnalyticsKey.Substring(0, 5)}...;" +
                    $" LogAnalytics Workspace: {logAnalyticsWorkspace}; Time: {DateTime.Now}");

                var interval = timer.ScheduleStatus.Next - timer.ScheduleStatus.Last;

                var parameters = new DatAlertParams(lastUpdated, next, severities, threatModelName);
                var data = await client.GetDataAsync(parameters);

                if (data.Trim() is "[]")
                {
                    log.LogInformation("Request was successful, but data is empty");
                    return;
                }

                log.LogInformation($"Data was received successfully: {data.Substring(0, data.Length > 15 ? 15 : data.Length)}...");
                await storage.PublishAsync(data);
            }
            catch (Exception ex) 
            {
                log.LogError(ex.Message);
                throw;
            }
        }
    }
}
