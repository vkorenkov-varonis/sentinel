﻿using System;

namespace Varonis.Sentinel.Functions.Helpers
{
    internal static class DateParser
    {
        public static DateTime Parse(string dateRange)
        {
            if (DateTime.TryParse(dateRange, out var date))
            { 
                return date;
            }

            var rangeArr = dateRange.Split(' ', StringSplitOptions.RemoveEmptyEntries);

            if (rangeArr.Length != 2 || !int.TryParse(rangeArr[0], out var number))
            {
                goto FormatException;
            }

            var sufix = rangeArr[1];
            var now = DateTime.UtcNow;

            if (sufix.StartsWith("sec")) return now.AddSeconds(-number);
            if (sufix.StartsWith("min")) return now.AddMinutes(-number);
            if (sufix.StartsWith("hour")) return now.AddHours(-number);
            if (sufix.StartsWith("day")) return now.AddDays(-number);
            if (sufix.StartsWith("week")) return now.AddDays(-number*7);
            if (sufix.StartsWith("month")) return now.AddMonths(-number);
            if (sufix.StartsWith("year")) return now.AddYears(-number);

            FormatException:
                throw new FormatException($"{dateRange} is not valid date.");
        }
    }
}
