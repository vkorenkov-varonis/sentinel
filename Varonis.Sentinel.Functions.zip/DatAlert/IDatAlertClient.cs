﻿using System;
using System.Threading.Tasks;

namespace Varonis.Sentinel.Functions.DatAlert
{
    internal interface IDatAlertClient
    {
        Task<string> GetDataAsync(DatAlertParams parameters);
    }
}