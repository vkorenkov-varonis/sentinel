﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Varonis.Sentinel.Functions.DatAlert
{
    internal class DatAlertClientFake : IDatAlertClient
    {
        private readonly Uri _baseUri;
        private readonly string _apikey;
        private readonly ILogger _log;

        public DatAlertClientFake(Uri baseUri, string apikey, ILogger log)
        {
            _baseUri = baseUri;
            _apikey = apikey;
            _log = log;
        }

        public async Task<string> GetDataAsync(DatAlertParams parameters)
        {
            var token = await GetAccessTokenAsync(_baseUri, _apikey).ConfigureAwait(false);

            _log.LogInformation($"Access token was received: {token}");

            using var client = new HttpClient();
            client.BaseAddress = _baseUri;
            var payload = new
            {
                StartDate = parameters.Start.ToUniversalTime().ToString("yyyy-MM-dd hh:mm:ss"),
                EndDate = parameters.End.ToUniversalTime().ToString("yyyy-MM-dd hh:mm:ss")
            };
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await client.PostAsJsonAsync("/Alert/alerts-post", payload)
                .ConfigureAwait(false);

            return await response.Content.ReadAsStringAsync()
                .ConfigureAwait(false);
        }

        private static async Task<string> GetAccessTokenAsync(Uri baseUri, string apikey)
        {
            using var client = new HttpClient();
            client.BaseAddress = baseUri;
            var payload = new Dictionary<string, string>
            {
                { "grant_type", "varonis-custom" },
                { "x-api-key", apikey }
            };
            var response = await client.PostAsync("/Auth", new FormUrlEncodedContent(payload))
                .ConfigureAwait(false);

            return await response.Content.ReadAsStringAsync()
                .ConfigureAwait(false);
        }
    }
}
