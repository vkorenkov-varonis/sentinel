﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq;

namespace Varonis.Sentinel.Functions.DatAlert
{
    internal class DatAlertClient : IDatAlertClient
    {
        private readonly Uri _baseUri;
        private readonly string _apikey;
        private readonly ILogger _log;

        public DatAlertClient(Uri baseUri, string apikey, ILogger log)
        {
            _baseUri = baseUri;
            _apikey = apikey;
            _log = log;
        }

        public async Task<string> GetDataAsync(DatAlertParams parameters)
        {
            var tokenJson = await GetAccessTokenAsync(_baseUri, _apikey).ConfigureAwait(false);

            var tokenInfo = ParseTokenInfo(tokenJson);

            if (tokenInfo is null) 
            {
                throw new Exception("Token object is not valid.");
            }

            var token = tokenInfo.Value.token;

            _log.LogInformation($"Access token was received: {token.Substring(0, 10)}...");

            using var client = new HttpClient();
            client.BaseAddress = _baseUri;
            var payload = new
            {
                IngestTimeFrom = parameters.Start.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss"),
                IngestTimeTo = parameters.End.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss"),
                Severities = parameters.Severities.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()),
            };
            _log.LogInformation($"Started to get data, start time: {payload.IngestTimeFrom}, end time: {payload.IngestTimeTo}");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            
            var response = await client.PostAsJsonAsync("api/alert/search/alerts", payload)
                .ConfigureAwait(false);

            return await response.Content.ReadAsStringAsync()
                .ConfigureAwait(false);
        }

        private static async Task<string> GetAccessTokenAsync(Uri baseUri, string apikey)
        {
            using var client = new HttpClient { BaseAddress = baseUri  };
            var payload = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                { "grant_type", "varonis_custom" },
                //{ "x-api-key", apikey }
            });
            var content = await payload.ReadAsByteArrayAsync().ConfigureAwait(false);
            client.DefaultRequestHeaders.Add("x-api-key", apikey);
            client.DefaultRequestHeaders.Host = baseUri.Host;
            var response = await client.PostAsync("api/authentication/api_keys/token", payload)
                .ConfigureAwait(false);

            return await response.Content.ReadAsStringAsync()
                .ConfigureAwait(false);
        }

        private static (string token, string token_type, int expiresIn)? ParseTokenInfo(string json)
        {
            var jelement = JsonSerializer.Deserialize<JsonElement>(json);

            return jelement.TryGetProperty("access_token", out var token)
                && jelement.TryGetProperty("token_type", out var token_type)
                && jelement.TryGetProperty("expires_in", out var expiresIn)
                ? (token.GetString(), token_type.GetString(), expiresIn.GetInt32()) 
                : null;
        }
    }
}
